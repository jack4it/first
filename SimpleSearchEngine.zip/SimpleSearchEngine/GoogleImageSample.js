{
 "kind": "customsearch#search",
 "url": {
  "type": "application/json",
  "template": "https://www.googleapis.com/customsearch/v1?q={searchTerms}&num={count?}&start={startIndex?}&lr={language?}&safe={safe?}&cx={cx?}&cref={cref?}&sort={sort?}&filter={filter?}&gl={gl?}&cr={cr?}&googlehost={googleHost?}&c2coff={disableCnTwTranslation?}&hq={hq?}&hl={hl?}&siteSearch={siteSearch?}&siteSearchFilter={siteSearchFilter?}&exactTerms={exactTerms?}&excludeTerms={excludeTerms?}&linkSite={linkSite?}&orTerms={orTerms?}&relatedSite={relatedSite?}&dateRestrict={dateRestrict?}&lowRange={lowRange?}&highRange={highRange?}&searchType={searchType}&fileType={fileType?}&rights={rights?}&imgSize={imgSize?}&imgType={imgType?}&imgColorType={imgColorType?}&imgDominantColor={imgDominantColor?}&alt=json"
 },
 "queries": {
  "nextPage": [
   {
    "title": "Google Custom Search - xbox",
    "totalResults": "2270000000",
    "searchTerms": "xbox",
    "count": 10,
    "startIndex": 11,
    "inputEncoding": "utf8",
    "outputEncoding": "utf8",
    "safe": "off",
    "cx": "014286577728960093843:43poecu5wua",
    "searchType": "image"
   }
  ],
  "request": [
   {
    "title": "Google Custom Search - xbox",
    "totalResults": "2270000000",
    "searchTerms": "xbox",
    "count": 10,
    "startIndex": 1,
    "inputEncoding": "utf8",
    "outputEncoding": "utf8",
    "safe": "off",
    "cx": "014286577728960093843:43poecu5wua",
    "searchType": "image"
   }
  ]
 },
 "context": {
  "title": "General purpose testing search engine"
 },
 "searchInformation": {
  "searchTime": 0.206383,
  "formattedSearchTime": "0.21",
  "totalResults": "2270000000",
  "formattedTotalResults": "2,270,000,000"
 },
 "items": [
  {
   "kind": "customsearch#result",
   "title": "Xbox.",
   "htmlTitle": "\u003cb\u003eXbox\u003c/b\u003e.",
   "link": "http://nxeassets.xbox.com/shaxam/0201/f1/09/f1097d8a-40e9-48c7-9744-5b7fc0d7b2ac.PNG?v=1",
   "displayLink": "www.xbox.com",
   "snippet": "Not all Xbox 360s are the same",
   "htmlSnippet": "Not all \u003cb\u003eXbox\u003c/b\u003e 360s are the same",
   "mime": "image/png",
   "fileFormat": "Image Document",
   "image": {
    "contextLink": "http://www.xbox.com/xbox360",
    "height": 200,
    "width": 200,
    "byteSize": 29491,
    "thumbnailLink": "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTGhAgIM-dQAnGWUABTMFKcKSRU3vdyXtiocp5_4__oa-EPZxjdH7JKkw",
    "thumbnailHeight": 104,
    "thumbnailWidth": 104
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Make XBOX 360 Logo With Adobe Photoshop [Tutorial] | SetiawanFarlin.",
   "htmlTitle": "Make \u003cb\u003eXBOX\u003c/b\u003e 360 Logo With Adobe Photoshop [Tutorial] | SetiawanFarlin.",
   "link": "http://2.bp.blogspot.com/-Zunl0d6e6Ig/UH8jngt5VOI/AAAAAAAACf4/zuMSrFieY_s/s1600/xbox+logo.jpg",
   "displayLink": "www.setiawanfarlin.com",
   "snippet": "to download the XBOX font.",
   "htmlSnippet": "to download the \u003cb\u003eXBOX\u003c/b\u003e font.",
   "mime": "image/jpeg",
   "image": {
    "contextLink": "http://www.setiawanfarlin.com/2012/10/make-xbox-360-logo-with-adobe-photoshop.html",
    "height": 900,
    "width": 1600,
    "byteSize": 69591,
    "thumbnailLink": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-9As04qGeQFp5LOexAE2CM3Q35ARSqGTM_j2GZaRJ0ARL_QxLai7JmclT",
    "thumbnailHeight": 84,
    "thumbnailWidth": 150
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Free Xbox Live Gold this weekend for pretty much everyone except ...",
   "htmlTitle": "Free \u003cb\u003eXbox\u003c/b\u003e Live Gold this weekend for pretty much everyone except \u003cb\u003e...\u003c/b\u003e",
   "link": "http://www.blogcdn.com/www.joystiq.com/media/2012/10/xbox360logo.png",
   "displayLink": "www.joystiq.com",
   "snippet": "Free Xbox Live Gold this",
   "htmlSnippet": "Free \u003cb\u003eXbox\u003c/b\u003e Live Gold this",
   "mime": "image/png",
   "fileFormat": "Image Document",
   "image": {
    "contextLink": "http://www.joystiq.com/2012/11/29/free-xbox-live-gold-this-weekend-for-pretty-much-everyone-except/",
    "height": 314,
    "width": 530,
    "byteSize": 74941,
    "thumbnailLink": "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQACSfFvlAW0fslz7Sl6cUEKyBt0WCKO9xD6GsxunbTbXqDctwB45F4m40",
    "thumbnailHeight": 78,
    "thumbnailWidth": 132
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Xbox LIVE Turns 10: A Decade of Entertainment",
   "htmlTitle": "\u003cb\u003eXbox\u003c/b\u003e LIVE Turns 10: A Decade of Entertainment",
   "link": "http://www.microsoft.com/global/en-us/news/publishingimages/ImageGallery/Images/Products/Xbox/screenshot_Xbox360Dash_Page.jpg",
   "displayLink": "www.microsoft.com",
   "snippet": "In 2010, the Xbox LIVE update",
   "htmlSnippet": "In 2010, the \u003cb\u003eXbox\u003c/b\u003e LIVE update",
   "mime": "image/jpeg",
   "image": {
    "contextLink": "http://www.microsoft.com/en-us/news/features/2012/nov12/11-15XboxLIVE.aspx",
    "height": 327,
    "width": 580,
    "byteSize": 121148,
    "thumbnailLink": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR8ZAYr5tmFrkylUkMC1RMLhGu95aBA7EY89gKSsqxbDjI_46yZ-saaDoAk",
    "thumbnailHeight": 76,
    "thumbnailWidth": 134
   }
  },
  {
   "kind": "customsearch#result",
   "title": "xbox-360.jpg?w=360&h=240&crop=1",
   "htmlTitle": "\u003cb\u003exbox\u003c/b\u003e-360.jpg?w=360&amp;h=240&amp;crop=1",
   "link": "http://timenerdworld.files.wordpress.com/2012/11/xbox-360.jpg?w=360&h=240&crop=1",
   "displayLink": "techland.time.com",
   "snippet": "Xbox 360",
   "htmlSnippet": "\u003cb\u003eXbox\u003c/b\u003e 360",
   "mime": "image/jpeg",
   "image": {
    "contextLink": "http://techland.time.com/2012/12/03/9-wishes-for-microsofts-next-xbox-whatever-its-called/",
    "height": 240,
    "width": 360,
    "byteSize": 24494,
    "thumbnailLink": "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSsFyCriXNuMaFaJpAwH3rqd1kWYRHLMeGyKD92jjmJVIFnhUMrsmb2OLY",
    "thumbnailHeight": 81,
    "thumbnailWidth": 121
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Microsoft Sending Xbox Live Veterans a Custom, Free Xbox 360 [",
   "htmlTitle": "Microsoft Sending \u003cb\u003eXbox\u003c/b\u003e Live Veterans a Custom, Free \u003cb\u003eXbox\u003c/b\u003e 360 [",
   "link": "http://img.gawkerassets.com/img/1857v08lbqyiyjpg/xlarge.jpg",
   "displayLink": "kotaku.com",
   "snippet": "Microsoft Sending Xbox Live",
   "htmlSnippet": "Microsoft Sending \u003cb\u003eXbox\u003c/b\u003e Live",
   "mime": "image/jpeg",
   "image": {
    "contextLink": "http://kotaku.com/5960013/microsoft-sending-xbox-live-veterans-a-custom-free-xbox-360",
    "height": 360,
    "width": 640,
    "byteSize": 34131,
    "thumbnailLink": "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTZulA1YgSwWG23GorLhR-S_4sEh4UnJ0241_0pOAkVfdX81mmZ_USE0dcT",
    "thumbnailHeight": 77,
    "thumbnailWidth": 137
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Microsoft cuts Xbox 360 price by $50, reveals new holiday bundles ...",
   "htmlTitle": "Microsoft cuts \u003cb\u003eXbox\u003c/b\u003e 360 price by $50, reveals new holiday bundles \u003cb\u003e...\u003c/b\u003e",
   "link": "http://boygeniusreport.files.wordpress.com/2012/10/xbox-holiday-bundle-2012.jpg?w=645&h=443",
   "displayLink": "bgr.com",
   "snippet": "Xbox 360 Price Cut",
   "htmlSnippet": "\u003cb\u003eXbox\u003c/b\u003e 360 Price Cut",
   "mime": "image/jpeg",
   "image": {
    "contextLink": "http://bgr.com/2012/10/17/xbox-360-price-cut-new-holiday-bundles-microsoft/",
    "height": 443,
    "width": 645,
    "byteSize": 102104,
    "thumbnailLink": "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTr0HOFkIlyLxvw0O9qPzkv7l_1j2mfr2Hy7LyB9NnwzJ75Bg4gk3Jw3I4",
    "thumbnailHeight": 94,
    "thumbnailWidth": 137
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Xbox 720 Specs Have Supposedly Been Leaked (rumor) | Gadget Review",
   "htmlTitle": "\u003cb\u003eXbox\u003c/b\u003e 720 Specs Have Supposedly Been Leaked (rumor) | Gadget Review",
   "link": "http://www.gadgetreview.com/wp-content/uploads/2012/11/Xbox-World-720-Mockup.jpg",
   "displayLink": "www.gadgetreview.com",
   "snippet": "The deets on the next Xbox,",
   "htmlSnippet": "The deets on the next \u003cb\u003eXbox\u003c/b\u003e,",
   "mime": "image/jpeg",
   "image": {
    "contextLink": "http://www.gadgetreview.com/2012/11/xbox-720-specs-have-supposedly-been-leaked.html",
    "height": 1695,
    "width": 1200,
    "byteSize": 357885,
    "thumbnailLink": "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQaJc6-trHXhYrlRUuoHwnS26FA2A5-QI5Sfr___G7DgJOmLL7mVA3RzCY",
    "thumbnailHeight": 150,
    "thumbnailWidth": 106
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Microsoft shipping Xbox Live 10th anniversary custom Xbox to early ...",
   "htmlTitle": "Microsoft shipping \u003cb\u003eXbox\u003c/b\u003e Live 10th anniversary custom \u003cb\u003eXbox\u003c/b\u003e to early \u003cb\u003e...\u003c/b\u003e",
   "link": "http://www.geek.com/wp-content/uploads/2012/11/xbox10.jpg",
   "displayLink": "www.geek.com",
   "snippet": "If you've been an Xbox Live",
   "htmlSnippet": "If you&#39;ve been an \u003cb\u003eXbox\u003c/b\u003e Live",
   "mime": "image/jpeg",
   "image": {
    "contextLink": "http://www.geek.com/articles/games/microsoft-shipping-10th-anniversary-custom-xbox-to-early-adopters-20121114/",
    "height": 711,
    "width": 800,
    "byteSize": 48841,
    "thumbnailLink": "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTgYBPEJf5rYrvlkxdMCD_lrDgXXir738GA75TENw5p3B82JZ4SMz-1tJWE",
    "thumbnailHeight": 127,
    "thumbnailWidth": 143
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Report: Next Xbox coming by 2013 holiday season | Games Blog ...",
   "htmlTitle": "Report: Next \u003cb\u003eXbox\u003c/b\u003e coming by 2013 holiday season | Games Blog \u003cb\u003e...\u003c/b\u003e",
   "link": "http://l3.yimg.com/bt/api/res/1.2/vMCVRBvfGmQB3GcryH0HOw--/YXBwaWQ9eW5ld3M7cT04NTt3PTMwMA--/http://media.zenfs.com/en-US/blogs/ygamesblog/next-xbox-2013.jpg",
   "displayLink": "games.yahoo.com",
   "snippet": "Xbox 360 and Kinect (Credit:",
   "htmlSnippet": "\u003cb\u003eXbox\u003c/b\u003e 360 and Kinect (Credit:",
   "mime": "image/jpeg",
   "image": {
    "contextLink": "http://games.yahoo.com/blogs/plugged-in/report-next-xbox-coming-2013-holiday-season-191606695.html",
    "height": 232,
    "width": 300,
    "byteSize": 6824,
    "thumbnailLink": "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcS5JwNAkigc8H5JIaJLP2Lak5Vk4MRUNh0sEPGohf1uDe2KkPVDGeYHY1A",
    "thumbnailHeight": 90,
    "thumbnailWidth": 116
   }
  }
 ]
}
