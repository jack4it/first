﻿namespace SimpleSearchEngine.Tests
{
    using System;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using SimpleSearchEngine.Filters;

    [TestClass]
    public class LogContextTests
    {
        #region Public Methods and Operators

        [AssemblyInitialize]
        public static void Initialize(TestContext testContext)
        {
            ////Database.SetInitializer(new DropCreateDatabaseAlways<LogContext>());
        }

        [TestMethod]
        public void CanSaveLog()
        {
            using (var ctx = new LogContext())
            {
                // arrange
                ctx.Database.ExecuteSqlCommand("truncate table [Logs]");
                var log = new Log { Timestamp = DateTime.UtcNow, Direction = LogDirection.Request, RawData = "request log test." };
                ctx.Logs.Add(log);

                // action
                var t = ctx.SaveChangesAsync();
                t.Wait();

                // assert
                Assert.AreEqual(1, log.LogId);

                Console.WriteLine("----- before truncation -----");
                foreach (var l in ctx.Logs)
                {
                    Console.WriteLine("{0}\t{1}\t{2}\t{3}", l.LogId, l.Direction, l.Timestamp, l.RawData);
                }

                ctx.Database.ExecuteSqlCommand("truncate table [Logs]");
                Console.WriteLine("----- after truncation -----");
                foreach (var l in ctx.Logs)
                {
                    Console.WriteLine("{0}\t{1}\t{2}\t{3}", l.LogId, l.Direction, l.Timestamp, l.RawData);
                }
            }
        }

        #endregion
    }
}
