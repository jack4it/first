﻿namespace SimpleSearchEngine.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using SimpleSearchEngine.Models;

    [TestClass]
    public class BingClientTests
    {
        #region Public Methods and Operators

        [TestMethod]
        public void CanCreateBingClient()
        {
            var client = new BingClient();
            Assert.IsNotNull(client);
        }

        [TestMethod]
        public void CanSearchBingImage()
        {
            var searchQuery = new SearchQuery { SearchType = SearchType.Image, Query = "xbox" };
            this.SearchBing(searchQuery);
        }

        [TestMethod]
        public void CanSearchBingNews()
        {
            var searchQuery = new SearchQuery { SearchType = SearchType.News, Query = "xbox" };
            this.SearchBing(searchQuery);
        }

        [TestMethod]
        public void CanSearchBingVideo()
        {
            var searchQuery = new SearchQuery { SearchType = SearchType.Video, Query = "xbox" };
            this.SearchBing(searchQuery);
        }

        [TestMethod]
        public void CanSearchBingWeb()
        {
            var searchQuery = new SearchQuery { SearchType = SearchType.Web, Query = "xbox" };
            this.SearchBing(searchQuery);
        }

        #endregion

        #region Methods

        private void SearchBing(SearchQuery searchQuery)
        {
            var client = new BingClient();
            SearchHelper.Search(searchQuery, client);
        }

        #endregion
    }
}
