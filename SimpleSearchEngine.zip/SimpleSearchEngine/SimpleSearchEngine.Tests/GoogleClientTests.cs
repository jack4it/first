﻿namespace SimpleSearchEngine.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using SimpleSearchEngine.Models;

    [TestClass]
    public class GoogleClientTests
    {
        #region Public Methods and Operators

        [TestMethod]
        public void CanCreateGoogleClient()
        {
            var client = new GoogleClient();
            Assert.IsNotNull(client);
        }

        [TestMethod]
        public void CanSearchGoogleImage()
        {
            var searchQuery = new SearchQuery { SearchType = SearchType.Image, Query = "xbox" };
            this.SearchGoogle(searchQuery);
        }

        [TestMethod]
        public void CanSearchGoogleNews()
        {
            var searchQuery = new SearchQuery { SearchType = SearchType.News, Query = "xbox" };
            this.SearchGoogle(searchQuery);
        }

        [TestMethod]
        public void CanSearchGoogleVideo()
        {
            var searchQuery = new SearchQuery { SearchType = SearchType.Video, Query = "xbox" };
            this.SearchGoogle(searchQuery);
        }

        [TestMethod]
        public void CanSearchGoogleWeb()
        {
            var searchQuery = new SearchQuery { SearchType = SearchType.Web, Query = "xbox" };
            this.SearchGoogle(searchQuery);
        }

        #endregion

        #region Methods

        private void SearchGoogle(SearchQuery searchQuery)
        {
            var client = new GoogleClient();
            SearchHelper.Search(searchQuery, client);
        }

        #endregion
    }
}
