﻿namespace SimpleSearchEngine.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;

    using Microsoft.Practices.Unity;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;

    using Newtonsoft.Json.Linq;

    using SimpleSearchEngine.Controllers;
    using SimpleSearchEngine.Models;

    [TestClass]
    public class SearchControllerTests
    {
        #region Public Methods and Operators

        [TestMethod]
        public void CanCreateSearchController()
        {
            var container = new UnityContainer();
            container.RegisterType<ISearchEngineClient, BingClient>("Bing", new TransientLifetimeManager());
            container.RegisterType<ISearchEngineClient, GoogleClient>("Google", new TransientLifetimeManager());

            var controller = container.Resolve<SearchController>();

            Assert.IsNotNull(controller);
        }

        [TestMethod]
        public void CanSearchThroughController()
        {
            var bingMock = new Mock<ISearchEngineClient>();
            bingMock.Setup(client => client.SearchAsync(It.IsAny<SearchQuery>()))
                    .Returns(
                        Task.FromResult<IEnumerable<SearchResultItem>>(
                            new List<SearchResultItem>
                                {
                                    new SearchResultItem
                                        {
                                            Title = "Result A", 
                                            Description = "Result A from Bing", 
                                            Source = SearchSource.Bing
                                        }
                                }));
            var googleMock = new Mock<ISearchEngineClient>();
            googleMock.Setup(client => client.SearchAsync(It.IsAny<SearchQuery>()))
                      .Returns(
                          Task.FromResult<IEnumerable<SearchResultItem>>(
                              new List<SearchResultItem>
                                  {
                                      new SearchResultItem
                                          {
                                              Title = "Result B", 
                                              Description = "Result B from Google", 
                                              Source = SearchSource.Google
                                          }
                                  }));
            var container = new UnityContainer();
            container.RegisterInstance("Bing", bingMock.Object);
            container.RegisterInstance("Google", googleMock.Object);

            var controller = container.Resolve<SearchController>();

            // ugly code to make this test work
            var configuration = new HttpConfiguration();
            var request = new HttpRequestMessage();
            controller.Request = request;
            controller.Request.Properties["MS_HttpConfiguration"] = configuration;

            var response = controller.Post(new SearchQuery { Query = "Some query", SearchType = SearchType.Web }).Result;

            Assert.IsTrue(response.IsSuccessStatusCode);
            var json = response.Content.ReadAsStringAsync().Result;
            Console.WriteLine(json);
            var jobj = JObject.Parse(json);
            Assert.IsTrue(jobj["Items"].HasValues);
            var enumerator = jobj["Items"].Children().GetEnumerator();
            var count = 0;
            while (enumerator.MoveNext())
            {
                count++;
            }

            Assert.AreEqual(2, count);
        }

        [TestMethod]
        public void ReturnNothingIfNoQuerySpecified()
        {
            var bingMock = new Mock<ISearchEngineClient>();
            bingMock.Setup(client => client.SearchAsync(new SearchQuery()))
                    .Returns(
                        Task.FromResult<IEnumerable<SearchResultItem>>(
                            new List<SearchResultItem>
                                {
                                    new SearchResultItem
                                        {
                                            Title = "Result A", 
                                            Description = "Result A from Bing", 
                                            Source = SearchSource.Bing
                                        }
                                }));
            var container = new UnityContainer();
            container.RegisterInstance("Bing", bingMock.Object);

            var controller = container.Resolve<SearchController>();

            // ugly code to make this test work
            var configuration = new HttpConfiguration();
            var request = new HttpRequestMessage();
            controller.Request = request;
            controller.Request.Properties["MS_HttpConfiguration"] = configuration;

            var response = controller.Post(new SearchQuery()).Result;

            Assert.IsTrue(response.IsSuccessStatusCode);
            var json = response.Content.ReadAsStringAsync().Result;
            Console.WriteLine(json);
            var jobj = JObject.Parse(json);
            Assert.IsFalse(jobj["Items"].HasValues);
        }

        #endregion
    }
}
