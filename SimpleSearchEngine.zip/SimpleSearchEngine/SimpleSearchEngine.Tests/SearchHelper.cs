﻿namespace SimpleSearchEngine.Tests
{
    using System;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using SimpleSearchEngine.Models;

    public static class SearchHelper
    {
        #region Public Methods and Operators

        public static void Search(SearchQuery searchQuery, ISearchEngineClient client)
        {
            var result = client.SearchAsync(searchQuery);
            var enumerator = result.Result.GetEnumerator();
            Assert.IsTrue(enumerator.MoveNext());
            var currentItem = enumerator.Current;
            Console.WriteLine("{0}:{1}:{2}:{3}", currentItem.Title, currentItem.Url, currentItem.Description, currentItem.ThumbnailUrl);
        }

        #endregion
    }
}
