﻿namespace SimpleSearchEngine.Models
{
    public enum SearchType
    {
        Web, 

        Image, 

        Video, 

        News, 
    }
}
