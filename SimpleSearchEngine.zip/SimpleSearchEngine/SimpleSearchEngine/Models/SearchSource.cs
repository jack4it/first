﻿namespace SimpleSearchEngine.Models
{
    public enum SearchSource
    {
        Bing, 

        Google, 
    }
}
