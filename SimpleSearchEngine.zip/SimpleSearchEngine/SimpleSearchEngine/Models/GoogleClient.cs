﻿namespace SimpleSearchEngine.Models
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web;

    using Newtonsoft.Json.Linq;

    public class GoogleClient : ISearchEngineClient
    {
        #region Constants

        private const string Api =
            "https://www.googleapis.com/customsearch/v1?key=AIzaSyDSiWLUhVzyK3on8KdmhANFAGyPpty4CaI&cx=014286577728960093843:43poecu5wua&q={0}{1}";

        #endregion

        #region Public Methods and Operators

        public async Task<IEnumerable<SearchResultItem>> SearchAsync(SearchQuery searchQuery)
        {
            using (var client = new HttpClient())
            {
                var uri = string.Format(
                    Api, HttpUtility.UrlEncode(searchQuery.Query), searchQuery.SearchType == SearchType.Image ? "&searchType=image" : string.Empty);
                var jsonString = await client.GetStringAsync(uri);
                var jobject = JObject.Parse(jsonString);

                ////Console.WriteLine(jobject.ToString(Formatting.Indented));
                var items = from item in jobject["items"].Children()
                            select new SearchResultItem
                                       {
                                           Title = (string)item["title"], 
                                           Url = (string)item["link"], 







                                           // Web, News, Video
                                           Description = (string)item["snippet"], 

                                           // Image
                                           ThumbnailUrl = item["image"] == null ? string.Empty : (string)item["image"]["thumbnailLink"], 
                                           Source = SearchSource.Google
                                       };
                return items;
            }
        }

        #endregion
    }
}
