﻿namespace SimpleSearchEngine.Models
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface ISearchEngineClient
    {
        #region Public Methods and Operators

        Task<IEnumerable<SearchResultItem>> SearchAsync(SearchQuery searchQuery);

        #endregion
    }
}
