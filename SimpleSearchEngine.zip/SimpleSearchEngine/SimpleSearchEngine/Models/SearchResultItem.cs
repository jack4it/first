﻿namespace SimpleSearchEngine.Models
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    public class SearchResultItem
    {
        #region Public Properties

        public string Description { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public SearchSource Source { get; set; }

        public string ThumbnailUrl { get; set; }

        public string Title { get; set; }

        public string Url { get; set; }

        #endregion
    }
}
