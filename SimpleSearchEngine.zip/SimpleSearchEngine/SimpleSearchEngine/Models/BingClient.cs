﻿namespace SimpleSearchEngine.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web;

    using Newtonsoft.Json.Linq;

    public class BingClient : ISearchEngineClient
    {
        #region Constants

        private const string AccountKey = "MxQb9k5tDXojFcLG1+eZwKYghxE1knkV+HAXH/5MEjo=";

        ////"https://api.datamarket.azure.com/Bing/Search/{0}?$format=json&$top=10&Options=%27DisableLocationDetection%27&WebSearchOptions=%27DisableHostCollpasing%27&Query=%27{1}%27";
        private const string ServiceOperation =
            "https://api.datamarket.azure.com/Bing/Search/{0}?$format=json&$top=10&Options=%27DisableLocationDetection%27&Query=%27{1}%27";

        #endregion

        #region Public Methods and Operators

        public async Task<IEnumerable<SearchResultItem>> SearchAsync(SearchQuery searchQuery)
        {
            using (var client = new HttpClient())
            {
                var param = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Format("{0}:{1}", AccountKey, AccountKey)));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", param);
                var uri = string.Format(ServiceOperation, searchQuery.SearchType, HttpUtility.UrlEncode(searchQuery.Query));
                var jsonString = await client.GetStringAsync(uri);
                var jobject = JObject.Parse(jsonString);

                ////Console.WriteLine(jobject.ToString(Formatting.Indented));
                var items = from item in jobject["d"]["results"].Children()
                            select new SearchResultItem
                                       {
                                           Title = (string)item["Title"], 
                                           Url = (string)item["Url"] ?? (string)item["MediaUrl"], 
                                        
                                           
                                           
                                           
                                           
                                           
                                           
                                           
                                           
                                           
                                           // Web, News
                                           Description = (string)item["Description"], 

                                           // Image, Video
                                           ThumbnailUrl =
                                               item["Thumbnail"] == null ? string.Empty : (string)item["Thumbnail"]["MediaUrl"], 
                                           Source = SearchSource.Bing
                                       };
                return items;
            }
        }

        #endregion
    }
}
