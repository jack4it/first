﻿namespace SimpleSearchEngine.Models
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    public class SearchQuery
    {
        #region Public Properties

        public string Query { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public SearchType SearchType { get; set; }

        #endregion
    }
}
