﻿namespace SimpleSearchEngine.Filters
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity;
    using System.Diagnostics;
    using System.IO;
    using System.Net.Http;
    using System.Web.Http.Controllers;
    using System.Web.Http.Filters;

    public class LogActionFilterAttribute : ActionFilterAttribute
    {
        #region Public Properties

        public override bool AllowMultiple
        {
            get
            {
                return false;
            }
        }

        #endregion

        #region Public Methods and Operators

        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            base.OnActionExecuted(actionExecutedContext);

            // logging response
            this.WriteLog(actionExecutedContext.Response.Content, LogDirection.Response);
        }

        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            base.OnActionExecuting(actionContext);

            // logging request
            this.WriteLog(actionContext.Request.Content, LogDirection.Request);
        }

        #endregion

        #region Methods

        private async void WriteLog(HttpContent content, LogDirection direction)
        {
            try
            {
                string raw;
                if (content is StreamContent)
                {
                    // HttpContent.ReadAsStringAsync doesn' really work on the request stream. So we seek to the begin of the stream by ourselves.
                    using (var reader = new StreamReader(await content.ReadAsStreamAsync()))
                    {
                        if (reader.BaseStream.CanSeek)
                        {
                            reader.BaseStream.Seek(0, SeekOrigin.Begin);
                        }

                        raw = await reader.ReadToEndAsync();
                    }
                }
                else
                {
                    raw = await content.ReadAsStringAsync();
                }

                using (var dbctx = new LogContext())
                {
                    dbctx.Logs.Add(new Log { Timestamp = DateTime.UtcNow, RawData = raw, Direction = direction });
                    await dbctx.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                Debug.Write(ex.ToString());
            }
        }

        #endregion
    }

    public class LogContext : DbContext
    {
        #region Constructors and Destructors

        public LogContext()
            : base("name=DefaultConnection")
        {
        }

        #endregion

        #region Public Properties

        public DbSet<Log> Logs { get; set; }

        #endregion
    }

    public class Log
    {
        #region Public Properties

        public LogDirection Direction { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int LogId { get; set; }

        public string RawData { get; set; }

        public DateTime Timestamp { get; set; }

        #endregion
    }

    public enum LogDirection
    {
        Request, 

        Response, 
    }
}
