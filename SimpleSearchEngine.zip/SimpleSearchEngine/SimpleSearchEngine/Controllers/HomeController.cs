﻿namespace SimpleSearchEngine.Controllers
{
    using System.Web.Mvc;

    using SimpleSearchEngine.Models;

    public class HomeController : Controller
    {
        #region Constructors and Destructors

        public HomeController(ISearchEngineClient[] clients)
        {
        }

        #endregion

        #region Public Methods and Operators

        public ActionResult Index(string returnUrl)
        {
            this.ViewBag.ReturnUrl = returnUrl;
            return this.View();
        }

        #endregion
    }
}
