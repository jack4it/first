﻿namespace SimpleSearchEngine.Controllers
{
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;

    using SimpleSearchEngine.Filters;
    using SimpleSearchEngine.Models;

    [LogActionFilter]
    public class SearchController : ApiController
    {
        #region Fields

        private readonly ISearchEngineClient[] clients;

        #endregion

        #region Constructors and Destructors

        public SearchController(ISearchEngineClient[] clients)
        {
            this.clients = clients;
        }

        #endregion

        #region Public Methods and Operators

        public async Task<HttpResponseMessage> Post(SearchQuery searchQuery)
        {
            // POST api/search
            // validation
            if (string.IsNullOrWhiteSpace(searchQuery.Query))
            {
                return this.Request.CreateResponse(
                    HttpStatusCode.OK, 
                    new { SearchQuery = searchQuery, Metadata = new { Duration = "0" }, Items = Enumerable.Empty<SearchResultItem>() });
            }

            var watch = new Stopwatch();
            watch.Start();

            var tasks = new Task<IEnumerable<SearchResultItem>>[this.clients.Length];
            for (var i = 0; i < this.clients.Length; i++)
            {
                var client = this.clients[i];
                tasks[i] = client.SearchAsync(searchQuery);
            }

            await Task.WhenAll(tasks);

            var results = tasks.SelectMany(task => task.Result);

            watch.Stop();
            var response = this.Request.CreateResponse(
                HttpStatusCode.OK, 
                new
                    {
                        SearchQuery = searchQuery, 
                        Metadata = new { Duration = watch.ElapsedMilliseconds.ToString(CultureInfo.InvariantCulture) }, 
                        Items = results
                    });
            return response;
        }

        #endregion
    }
}
