﻿namespace SimpleSearchEngine
{
    using System;
    using System.Net.Http;
    using System.Web.Configuration;
    using System.Web.Http;
    using System.Web.Http.Controllers;
    using System.Web.Http.Dispatcher;
    using System.Web.Mvc;

    using Microsoft.Practices.Unity;

    using SimpleSearchEngine.Models;

    public static class UnityConfig
    {
        #region Public Methods and Operators

        public static void Initialize()
        {
            var container = new UnityContainer();
            RegisterServices(container);
            DependencyResolver.SetResolver(type => container.Resolve(type), type => container.ResolveAll(type));
            GlobalConfiguration.Configuration.Services.Replace(typeof(IHttpControllerActivator), new UnityHttpControllerActivator(container));
        }

        #endregion

        #region Methods

        private static void RegisterServices(IUnityContainer container)
        {
            var setting = WebConfigurationManager.AppSettings["SearchEngineClients"];

            if (setting.Contains("Bing"))
            {
                container.RegisterType<ISearchEngineClient, BingClient>("Bing", new TransientLifetimeManager());
            }

            if (setting.Contains("Google"))
            {
                container.RegisterType<ISearchEngineClient, GoogleClient>("Google", new TransientLifetimeManager());
            }
        }

        #endregion

        private class UnityHttpControllerActivator : IHttpControllerActivator
        {
            #region Fields

            private readonly IUnityContainer container;

            #endregion

            #region Constructors and Destructors

            public UnityHttpControllerActivator(IUnityContainer container)
            {
                this.container = container;
            }

            #endregion

            #region Public Methods and Operators

            public IHttpController Create(HttpRequestMessage request, HttpControllerDescriptor controllerDescriptor, Type controllerType)
            {
                return (IHttpController)this.container.Resolve(controllerType);
            }

            #endregion
        }
    }
}
