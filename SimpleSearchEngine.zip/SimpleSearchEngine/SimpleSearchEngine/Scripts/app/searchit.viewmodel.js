﻿window.searchitApp = window.searchitApp || {};

window.searchitApp.searchResultViewModel = (function (ko, datacontext, model) {
    var error = ko.observable();
    var searchInProgress = ko.observable();
    var duration = ko.observable(0);

    var searchType = ko.observable();
    var query = ko.observable();
    var items = ko.observableArray();

    var searchit = function () {
        error("");
        searchInProgress(true);
        datacontext.searchitRemotely({ SearchType: searchType(), Query: query() })
            .done(function (searchResult) {
                // process the result
                var result = new model.SearchResult(searchResult);
                searchType(result.SearchQuery.SearchType);
                query(result.SearchQuery.Query);
                duration(result.Metadata.Duration);
                items.removeAll();
                $.each(result.Items, function (i, value) { items.push(value); });
            })
            .fail(function(err) {
                error(err.responseText);
            })
            .always(function () { searchInProgress(false); });
    };

    return {
        error: error,
        searchInProgress: searchInProgress,
        duration: duration,
        searchType: searchType,
        query: query,
        items: items,
        searchit: searchit
    };

})(ko, searchitApp.datacontext, searchitApp.searchResultModel);

// Initiate the Knockout bindings
ko.applyBindings(window.searchitApp.searchResultViewModel);
