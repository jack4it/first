﻿window.searchitApp = window.searchitApp || {};

window.searchitApp.searchResultModel = (function (ko) {

    function SearchResult(data) {
        var self = this;
        data = data || {};

        self.SearchQuery = data.SearchQuery;
        self.Metadata = data.Metadata;
        self.Items = $.map(data.Items, function (dataItem) { return new SearchResultItem(dataItem); });
    }

    function SearchResultItem(data) {
        var self = this;
        data = data || {};

        self.Title = data.Title;
        self.Description = data.Description;
        self.Url = data.Url;
        self.ThumbnailUrl = data.ThumbnailUrl;
        self.IsImage = self.ThumbnailUrl != "";
        self.IsNonImage = !self.IsImage;
        self.Source = data.Source;
    }

    return {
        SearchResultItem: SearchResultItem,
        SearchResult: SearchResult
    };

})(ko);
