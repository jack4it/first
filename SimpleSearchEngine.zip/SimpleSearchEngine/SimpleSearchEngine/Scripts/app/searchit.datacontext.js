﻿window.searchitApp = window.searchitApp || {};

window.searchitApp.datacontext = (function (ko) {

    function searchitRemotely(searchQuery) {
        return ajaxRequest("post", apiUrl(), searchQuery);
    }

    // Private
    function ajaxRequest(type, url, data) { // Ajax helper
        var options = {
            dataType: "json",
            contentType: "application/json",
            cache: false,
            type: type,
            data: ko.toJSON(data)
        };

        return $.ajax(url, options);
    }

    // routes
    function apiUrl() { return "/api/search/"; }

    return {
        searchitRemotely: searchitRemotely
    };

})(ko);
