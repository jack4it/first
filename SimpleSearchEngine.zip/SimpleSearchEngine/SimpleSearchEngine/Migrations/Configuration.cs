namespace SimpleSearchEngine.Migrations
{
    using System.Data.Entity.Migrations;

    using SimpleSearchEngine.Filters;

    internal sealed class Configuration : DbMigrationsConfiguration<LogContext>
    {
        #region Constructors and Destructors

        public Configuration()
        {
            this.AutomaticMigrationsEnabled = true;
        }

        #endregion

        #region Methods

        protected override void Seed(LogContext context)
        {
            // This method will be called after migrating to the latest version.

            // You can use the DbSet<T>.AddOrUpdate() helper extension method 
            // to avoid creating duplicate seed data. E.g.
            // context.People.AddOrUpdate(
            // p => p.FullName,
            // new Person { FullName = "Andrew Peters" },
            // new Person { FullName = "Brice Lambson" },
            // new Person { FullName = "Rowan Miller" }
            // );
        }

        #endregion
    }
}
