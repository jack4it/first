{
  "d": {
    "results": [
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=0&$top=1",
          "type": "VideoResult"
        },
        "ID": "e4955bda-5bcd-4b8a-b016-d6d175deddea",
        "Title": "XBOX LIVE CODE GENERATOR - FREE MULTIPLAYER ...",
        "MediaUrl": "http://www.dailymotion.com/video/xjmgwz_xbox-live-code-generator-free-multiplayer-download-on-http-xbox-lcg-blogspot-com_videogames",
        "DisplayUrl": "http://www.bing.com/videos/search?mkt=en-US&q=&FORM=MONITR&id=16902806BF4BBF1181BF16902806BF4BBF1181BF&view=detail",
        "RunTime": "101733",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts4.mm.bing.net/th?id=V.5047532239978547&pid=15.1&W=160&H=89",
          "ContentType": "image/jpg",
          "Width": "160",
          "Height": "89",
          "FileSize": "24299"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=1&$top=1",
          "type": "VideoResult"
        },
        "ID": "eed35034-bcaf-426d-b343-864afeaa13b6",
        "Title": "Xbox 360 FUTURE",
        "MediaUrl": "http://www.youtube.com/watch?v=uZmcb-JeKGE",
        "DisplayUrl": "http://www.bing.com/videos/search?mkt=en-US&q=&FORM=MONITR&id=5890CB11922D32CDA7225890CB11922D32CDA722&view=detail",
        "RunTime": "96208",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts2.mm.bing.net/th?id=V.4805579591974989&pid=15.1&W=160&H=90",
          "ContentType": "image/jpg",
          "Width": "160",
          "Height": "90",
          "FileSize": "7499"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=2&$top=1",
          "type": "VideoResult"
        },
        "ID": "75eea03c-5806-427e-8481-54d8b9bd0322",
        "Title": "Minecraft: Xbox 360 Edition Full Adventure!",
        "MediaUrl": "http://www.youtube.com/watch?v=TJrp31zEJ3s",
        "DisplayUrl": "http://www.bing.com/videos/search?mkt=en-US&q=&FORM=MONITR&id=EB9730B41C35C93482ADEB9730B41C35C93482AD&view=detail",
        "RunTime": "12445000",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts1.mm.bing.net/th?id=V.4536345304825924&pid=15.1&W=160&H=89",
          "ContentType": "image/jpg",
          "Width": "160",
          "Height": "89",
          "FileSize": "17887"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=3&$top=1",
          "type": "VideoResult"
        },
        "ID": "34902e31-5569-412a-a4e9-3b5f3f21c49d",
        "Title": "Minecraft Breaks Xbox Sale Records",
        "MediaUrl": "http://www.5min.com/Video/Minecraft-Breaks-Xbox-Sale-Records-517363819",
        "DisplayUrl": "http://www.bing.com/videos/search?mkt=en-US&q=&FORM=MONITR&id=0DAB6EA28929350471BC0DAB6EA28929350471BC&view=detail",
        "RunTime": "178000",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts3.mm.bing.net/th?id=V.4584573477650542&pid=15.1&W=160&H=89",
          "ContentType": "image/jpg",
          "Width": "160",
          "Height": "89",
          "FileSize": "16636"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=4&$top=1",
          "type": "VideoResult"
        },
        "ID": "bb74f10f-1137-4357-a07d-66c24bab3218",
        "Title": "Saw Xbox 360 Gameplay HD",
        "MediaUrl": "http://www.youtube.com/watch?v=NONH9mlBHw4",
        "DisplayUrl": "http://www.bing.com/videos/search?mkt=en-US&q=&FORM=MONITR&id=DAB89291C7231D0EAD66DAB89291C7231D0EAD66&view=detail",
        "RunTime": "588000",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts4.mm.bing.net/th?id=V.4908134847217711&pid=15.1&W=160&H=94",
          "ContentType": "image/jpg",
          "Width": "160",
          "Height": "94",
          "FileSize": "9516"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=5&$top=1",
          "type": "VideoResult"
        },
        "ID": "de466cc1-6024-4fc4-ad05-1299b4006031",
        "Title": "Mario in Scribblenauts, Skyrim Dragon Riding, and Xbox Live ...",
        "MediaUrl": "http://www.metacafe.com/watch/9249532/mario_in_scribblenauts_skyrim_dragon_riding_and_xbox_live_indie_trouble_hard_news_clip/",
        "DisplayUrl": "http://www.bing.com/videos/search?mkt=en-US&q=&FORM=MONITR&id=C4AAD41D1C08B6A6C23EC4AAD41D1C08B6A6C23E&view=detail",
        "RunTime": "155132",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts2.mm.bing.net/th?id=V.4604175740502037&pid=15.1&W=160&H=89",
          "ContentType": "image/jpg",
          "Width": "160",
          "Height": "89",
          "FileSize": "20105"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=6&$top=1",
          "type": "VideoResult"
        },
        "ID": "607b6c98-5fef-4397-be58-6cf8ec7ba5ee",
        "Title": "'House of the Dead III' (Xbox) Preview",
        "MediaUrl": "http://www.g4tv.com/videos/24693/house-of-the-dead-iii-xbox-preview/",
        "DisplayUrl": "http://www.bing.com/videos/search?mkt=en-US&q=&FORM=MONITR&id=F275A0AC5BED8D16286FF275A0AC5BED8D16286F&view=detail",
        "RunTime": "67250",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts3.mm.bing.net/th?id=V.4733699054698530&pid=15.1&W=160&H=113",
          "ContentType": "image/jpg",
          "Width": "160",
          "Height": "113",
          "FileSize": "17537"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=7&$top=1",
          "type": "VideoResult"
        },
        "ID": "0d65edd6-47b3-48b8-8198-3cbfd493dd87",
        "Title": "xbox_commercial",
        "MediaUrl": "http://www.youtube.com/watch?v=ALl6cagS2ZE",
        "DisplayUrl": "http://www.bing.com/videos/search?mkt=en-US&q=&FORM=MONITR&id=B648DDCFB8335B8687F0B648DDCFB8335B8687F0&view=detail",
        "RunTime": "92000",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts3.mm.bing.net/th?id=V.5057024137363626&pid=15.1&W=160&H=97",
          "ContentType": "image/jpg",
          "Width": "160",
          "Height": "97",
          "FileSize": "11344"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=8&$top=1",
          "type": "VideoResult"
        },
        "ID": "0a0c7888-1306-4afa-846a-957044883866",
        "Title": "Xbox 360 Dashboard - NXE Old vs NXE Kinect",
        "MediaUrl": "http://www.dailymotion.com/video/xfi8sp_xbox-360-dashboard-nxe-old-vs-nxe-kinect_videogames",
        "DisplayUrl": "http://www.bing.com/videos/search?mkt=en-US&q=&FORM=MONITR&id=D784E18607E2C5720C3FD784E18607E2C5720C3F&view=detail",
        "RunTime": "118000",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts4.mm.bing.net/th?id=V.4895425995145371&pid=15.1&W=160&H=89",
          "ContentType": "image/jpg",
          "Width": "160",
          "Height": "89",
          "FileSize": "8458"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=9&$top=1",
          "type": "VideoResult"
        },
        "ID": "697a0134-ed20-4180-b84c-1b678e098b6d",
        "Title": "Forza Horizon Rally Expansion Pack DLC Game Free On ...",
        "MediaUrl": "http://www.metacafe.com/watch/9575747/forza_horizon_rally_expansion_pack_dlc_game_free_on_xbox_360/",
        "DisplayUrl": "http://www.bing.com/videos/search?mkt=en-US&q=&FORM=MONITR&id=E98FC716EAD2089B7462E98FC716EAD2089B7462&view=detail",
        "RunTime": "152206",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts3.mm.bing.net/th?id=VB.276913850874&pid=15.1&W=160&H=89",
          "ContentType": "image/jpg",
          "Width": "160",
          "Height": "89",
          "FileSize": "19831"
        }
      }
    ],
    "__next": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Video?Options='DisableLocationDetection'&Query='xbox'&$skip=10&$top=10"
  }
}
