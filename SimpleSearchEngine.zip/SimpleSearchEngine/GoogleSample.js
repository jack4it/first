{
 "kind": "customsearch#search",
 "url": {
  "type": "application/json",
  "template": "https://www.googleapis.com/customsearch/v1?q={searchTerms}&num={count?}&start={startIndex?}&lr={language?}&safe={safe?}&cx={cx?}&cref={cref?}&sort={sort?}&filter={filter?}&gl={gl?}&cr={cr?}&googlehost={googleHost?}&c2coff={disableCnTwTranslation?}&hq={hq?}&hl={hl?}&siteSearch={siteSearch?}&siteSearchFilter={siteSearchFilter?}&exactTerms={exactTerms?}&excludeTerms={excludeTerms?}&linkSite={linkSite?}&orTerms={orTerms?}&relatedSite={relatedSite?}&dateRestrict={dateRestrict?}&lowRange={lowRange?}&highRange={highRange?}&searchType={searchType}&fileType={fileType?}&rights={rights?}&imgSize={imgSize?}&imgType={imgType?}&imgColorType={imgColorType?}&imgDominantColor={imgDominantColor?}&alt=json"
 },
 "queries": {
  "nextPage": [
   {
    "title": "Google Custom Search - bill",
    "totalResults": "219000000",
    "searchTerms": "bill",
    "count": 10,
    "startIndex": 11,
    "inputEncoding": "utf8",
    "outputEncoding": "utf8",
    "safe": "off",
    "cx": "014286577728960093843:43poecu5wua"
   }
  ],
  "request": [
   {
    "title": "Google Custom Search - bill",
    "totalResults": "219000000",
    "searchTerms": "bill",
    "count": 10,
    "startIndex": 1,
    "inputEncoding": "utf8",
    "outputEncoding": "utf8",
    "safe": "off",
    "cx": "014286577728960093843:43poecu5wua"
   }
  ]
 },
 "context": {
  "title": "General purpose testing search engine"
 },
 "searchInformation": {
  "searchTime": 0.708888,
  "formattedSearchTime": "0.71",
  "totalResults": "219000000",
  "formattedTotalResults": "219,000,000"
 },
 "items": [
  {
   "kind": "customsearch#result",
   "title": "Contributors - MSN Money: Personal finance & investing news experts",
   "htmlTitle": "Contributors - MSN Money: Personal finance &amp; investing news experts",
   "link": "http://money.msn.com/common/commentary.aspx",
   "displayLink": "money.msn.com",
   "snippet": "BILL FLECKENSTEIN. Fed drops the pretense, buys bonds. The Federal   Reserve's new policy 'twist' proves that its old money-printing habits die hard.",
   "htmlSnippet": "\u003cb\u003eBILL\u003c/b\u003e FLECKENSTEIN. Fed drops the pretense, buys bonds. The Federal \u003cbr\u003e  Reserve&#39;s new policy &#39;twist&#39; proves that its old money-printing habits die hard.",
   "formattedUrl": "money.msn.com/common/commentary.aspx",
   "htmlFormattedUrl": "money.msn.com/common/commentary.aspx",
   "pagemap": {
    "cse_image": [
     {
      "src": "http://col.stb.s-msn.com/i/A7/ABAB024E92C79A8FA48874152873.jpg"
     }
    ],
    "cse_thumbnail": [
     {
      "width": "108",
      "height": "81",
      "src": "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcScHTm_9z8SEW7mrL5vkPcL-RVZlBwBOIOZQiZmymF0x58UWvGOnIrh"
     }
    ],
    "metatags": [
     {
      "fb:app_id": "132970837947",
      "og:type": "article",
      "og:site_name": "MSNMoney"
     }
    ]
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Russian parliament OKs anti-US adoption bill",
   "htmlTitle": "Russian parliament OKs anti-US adoption \u003cb\u003ebill\u003c/b\u003e",
   "link": "http://news.msn.com/world/russian-parliament-oks-anti-us-adoption-bill",
   "displayLink": "news.msn.com",
   "snippet": "1 day ago ... A controversial bill that would halt American adoptions of Russian children was   approved by the upper chamber of the Russian parliament.",
   "htmlSnippet": "1 day ago \u003cb\u003e...\u003c/b\u003e A controversial \u003cb\u003ebill\u003c/b\u003e that would halt American adoptions of Russian children was \u003cbr\u003e  approved by the upper chamber of the Russian parliament.",
   "formattedUrl": "news.msn.com/world/russian-parliament-oks-anti-us-adoption-bill",
   "htmlFormattedUrl": "news.msn.com/world/russian-parliament-oks-anti-us-adoption-\u003cb\u003ebill\u003c/b\u003e",
   "pagemap": {
    "cse_image": [
     {
      "src": "http://col.stb.s-msn.com/amnews/i/amnews/i/1c/4742de44fa15dded8f77da830c0b5_h145_w210_m6_lfalse.jpg"
     }
    ],
    "metatags": [
     {
      "application-name": "Russian parliament OKs anti-US adoption bill",
      "msapplication-tilecolor": "#d24400",
      "msapplication-tileimage": "/content/images/MSNButterfly.png",
      "og:title": "Russian parliament OKs anti-US adoption bill",
      "og:description": "A controversial bill that would halt American adoptions of Russian children was approved by the upper chamber of the Russian parliament. The bill is retaliation for a new U.S. law targeting Russian human rights violators.",
      "og:image": "http://col.stb.s-msn.com/amnews/i/amnews/i/1c/4742de44fa15dded8f77da830c0b5_h145_w210_m6_lfalse.jpg",
      "og:url": "http://news.msn.com/world/russian-parliament-oks-anti-us-adoption-bill",
      "og:type": "article",
      "fb:app_id": "132970837947"
     }
    ]
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Good Samaritan pays family's Christmas Wal-Mart bill",
   "htmlTitle": "Good Samaritan pays family&#39;s Christmas Wal-Mart \u003cb\u003ebill\u003c/b\u003e",
   "link": "http://now.msn.com/good-samaritan-pays-familys-christmas-wal-mart-bill",
   "displayLink": "now.msn.com",
   "snippet": "10 hours ago ... A Good Samaritan paid a family's $211 Wal-Mart bill in Altoona, Iowa.",
   "htmlSnippet": "10 hours ago \u003cb\u003e...\u003c/b\u003e A Good Samaritan paid a family&#39;s $211 Wal-Mart \u003cb\u003ebill\u003c/b\u003e in Altoona, Iowa.",
   "formattedUrl": "now.msn.com/good-samaritan-pays-familys-christmas-wal-mart-bill",
   "htmlFormattedUrl": "now.msn.com/good-samaritan-pays-familys-christmas-wal-mart-\u003cb\u003ebill\u003c/b\u003e",
   "pagemap": {
    "cse_image": [
     {
      "src": "http://blu.stb.s-msn.com/i/CA/703360D4CD18B752D0688B67223A1F.jpg"
     }
    ],
    "cse_thumbnail": [
     {
      "width": "225",
      "height": "225",
      "src": "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTPFuqiRxNwmbnjFHbqP1d9p2oJVqlxxiwTJMiksUoJzUzZXWQGzLzlVkf6"
     }
    ],
    "metatags": [
     {
      "fb:app_id": "132970837947",
      "og:title": "Stranger picks up family's $211 Wal-Mart Christmas bill",
      "og:type": "article",
      "og:url": "http://now.msn.com/good-samaritan-pays-familys-christmas-wal-mart-bill",
      "og:image": "http://blu.stb.s-msn.com/i/CA/703360D4CD18B752D0688B67223A1F.jpg",
      "og:site_name": "msnNOW",
      "og:description": "Here's a last bit of Christmas cheer to take you into 2013. Ruby Modlin was shopping at an Iowa Wal-Mart when she noticed a fellow shopper, who would catch her eye and then look away. She chalked it up to an old acquaintance -- and was shocked when he jumped in line to pay her $211 grocery bill, swiping his credit card before she could stop him. The anonymous man pointed out his waiting wife and daughter and said they'd been scanning for a beneficiary and \"picked\" Modlin. They then walked away -- leaving Modlin and her family in tears: \"We were too busy crying, and the register people were smiling.\"",
      "news_keywords": "random act of kindness, random act of kindness christmas, christmas walmart gift",
      "pageid": "251635146",
      "pagemeta": "s:.desktop|p:.desktop|a:|cn:0009|ua:Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)|im:False|utc:2012-12-27 15:26:44Z|vn:Desktop|"
     }
    ]
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Russian parliament OKs anti-US adoption bill",
   "htmlTitle": "Russian parliament OKs anti-US adoption \u003cb\u003ebill\u003c/b\u003e",
   "link": "http://news.msn.com/world/video?videoid=f8930ff4-8d9a-49f2-a98b-7c831bddadd3",
   "displayLink": "news.msn.com",
   "snippet": "23 hours ago ... The upper chamber of Russia's parliament on Wednesday unanimously voted in   favor of a measure banning Americans from adopting Russian ...",
   "htmlSnippet": "23 hours ago \u003cb\u003e...\u003c/b\u003e The upper chamber of Russia&#39;s parliament on Wednesday unanimously voted in \u003cbr\u003e  favor of a measure banning Americans from adopting Russian \u003cb\u003e...\u003c/b\u003e",
   "formattedUrl": "news.msn.com/world/video?videoid=f8930ff4-8d9a-49f2-a98b...",
   "htmlFormattedUrl": "news.msn.com/world/video?videoid=f8930ff4-8d9a-49f2-a98b...",
   "pagemap": {
    "cse_image": [
     {
      "src": "http://img1.catalog.video.msn.com/image.aspx?uuid=f8930ff4-8d9a-49f2-a98b-7c831bddadd3&w=200&h=200&so=4"
     }
    ],
    "cse_thumbnail": [
     {
      "width": "160",
      "height": "160",
      "src": "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcQHPSpu3UJYz0GunVcR-rgbyq2bJhTr1ivTpgzZFrHigs5hqtz-BNIbcEh_"
     }
    ],
    "metatags": [
     {
      "application-name": "Russian parliament OKs anti-US adoption bill",
      "msapplication-tilecolor": "#d24400",
      "msapplication-tileimage": "/content/images/MSNButterfly.png",
      "og:title": "Russian parliament OKs anti-US adoption bill",
      "og:description": "The upper chamber of Russia's parliament on Wednesday unanimously voted in favor of a measure banning Americans from adopting Russian children.",
      "og:image": "http://img1.catalog.video.msn.com/image.aspx?uuid=f8930ff4-8d9a-49f2-a98b-7c831bddadd3&w=200&h=200&so=4",
      "og:url": "http://news.msn.com/world/video?videoid=f8930ff4-8d9a-49f2-a98b-7c831bddadd3",
      "og:type": "article",
      "fb:app_id": "132970837947"
     }
    ]
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Russia passes bill banning Americans from ... - msnNOW - Bing",
   "htmlTitle": "Russia passes \u003cb\u003ebill\u003c/b\u003e banning Americans from \u003cb\u003e...\u003c/b\u003e - msnNOW - Bing",
   "link": "http://now.msn.com/russia-passes-anti-american-adoption-ban",
   "displayLink": "now.msn.com",
   "snippet": "20 hours ago ... Russia's parliament passes a bill that prevents United States citizens from   adopting Russian children.",
   "htmlSnippet": "20 hours ago \u003cb\u003e...\u003c/b\u003e Russia&#39;s parliament passes a \u003cb\u003ebill\u003c/b\u003e that prevents United States citizens from \u003cbr\u003e  adopting Russian children.",
   "formattedUrl": "now.msn.com/russia-passes-anti-american-adoption-ban",
   "htmlFormattedUrl": "now.msn.com/russia-passes-anti-american-adoption-ban",
   "pagemap": {
    "cse_image": [
     {
      "src": "http://blu.stb.s-msn.com/i/D7/BEA788334F08D4ABD71529377065.jpg"
     }
    ],
    "cse_thumbnail": [
     {
      "width": "225",
      "height": "225",
      "src": "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcQy59IxN4EAKkMXRIUZkFZytAfgtP7VGsmzRh9ji4LNDbai6vXRkN9oFP0H"
     }
    ],
    "metatags": [
     {
      "fb:app_id": "132970837947",
      "og:title": "Russia passes bill banning Americans from adopting Russian children",
      "og:type": "article",
      "og:url": "http://now.msn.com/russia-passes-anti-american-adoption-ban",
      "og:image": "http://blu.stb.s-msn.com/i/D7/BEA788334F08D4ABD71529377065.jpg",
      "og:site_name": "msnNOW",
      "og:description": "Russia's parliament voted unanimously?to pass a bill Wednesday that prevents Americans from adopting Russian children. The bill, which will now be sent to President Vladimir Putin for approval, is Russia's response to a bill just passed in the United States that would punish Russians accused of human rights violations.",
      "news_keywords": "Russian adoption ban, Russia adoption ban, America adoption ban, United States adoption ban",
      "pageid": "251635146",
      "pagemeta": "s:.desktop|p:.desktop|a:|cn:2308|ua:Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)|im:False|utc:2012-12-27 13:47:48Z|vn:Desktop|"
     }
    ]
   }
  },
  {
   "kind": "customsearch#result",
   "title": "House Republicans eye limited fiscal cliff bill: Thomson Reuters ...",
   "htmlTitle": "House Republicans eye limited fiscal cliff \u003cb\u003ebill\u003c/b\u003e: Thomson Reuters \u003cb\u003e...\u003c/b\u003e",
   "link": "http://money.msn.com/business-news/article.aspx?feed=OBR&date=20121218&id=15915622",
   "displayLink": "money.msn.com",
   "snippet": "Dec 18, 2012 ... WASHINGTON (Reuters) - With time running short before a Dec. 31 deadline,   House of Representatives Speaker John Boehner will begin work ...",
   "htmlSnippet": "Dec 18, 2012 \u003cb\u003e...\u003c/b\u003e WASHINGTON (Reuters) - With time running short before a Dec. 31 deadline, \u003cbr\u003e  House of Representatives Speaker John Boehner will begin work \u003cb\u003e...\u003c/b\u003e",
   "formattedUrl": "money.msn.com/business-news/article.aspx?feed=OBR&date...id...",
   "htmlFormattedUrl": "money.msn.com/business-news/article.aspx?feed=OBR&amp;date...id...",
   "pagemap": {
    "cse_image": [
     {
      "src": "http://col.stc.s-msn.com/br/sc/i/2c/78729b9c947e78451234910f29ca55.png"
     }
    ],
    "metatags": [
     {
      "fb:app_id": "132970837947",
      "og:title": "House Republicans eye limited fiscal cliff bill: Thomson Reuters",
      "og:type": "article",
      "og:url": "http://money.msn.com/business-news/article.aspx?feed=OBR&date=20121218&id=15915622",
      "og:image": "http://col.stc.s-msn.com/br/sc/i/2c/78729b9c947e78451234910f29ca55.png",
      "og:site_name": "MSNMoney",
      "og:description": "WASHINGTON (Reuters) - With time running short before a Dec. 31 deadline, House of Representatives Speaker John Boehner will begin work on legislation that simply would extend current low income tax"
     }
    ]
   }
  },
  {
   "kind": "customsearch#result",
   "title": "How not to pay your bills - 1 - manage debt - MSN Money",
   "htmlTitle": "How not to pay your \u003cb\u003ebills\u003c/b\u003e - 1 - manage debt - MSN Money",
   "link": "http://money.msn.com/debt-management/how-not-to-pay-your-bills-weston.aspx",
   "displayLink": "money.msn.com",
   "snippet": "Oct 12, 2011 ... Here's how to dodge the repo man and buy some time while you try to pull your   financial life together. - MSN Money debt-management tips and ...",
   "htmlSnippet": "Oct 12, 2011 \u003cb\u003e...\u003c/b\u003e Here&#39;s how to dodge the repo man and buy some time while you try to pull your \u003cbr\u003e  financial life together. - MSN Money debt-management tips and \u003cb\u003e...\u003c/b\u003e",
   "cacheId": "d4I7OEGYSfQJ",
   "formattedUrl": "money.msn.com/debt.../how-not-to-pay-your-bills-weston.aspx",
   "htmlFormattedUrl": "money.msn.com/debt.../how-not-to-pay-your-\u003cb\u003ebills\u003c/b\u003e-weston.aspx",
   "pagemap": {
    "cse_image": [
     {
      "src": "http://col.stb.s-msn.com/i/75/EB94FFD21D420CB9CF8F3CDAFC3F0.jpg"
     }
    ],
    "cse_thumbnail": [
     {
      "width": "242",
      "height": "168",
      "src": "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTGd_t51oECjHPVOBaBukMuDV4XGGWaMEans4XueQA-7IP7daT9ut6oIHG9"
     }
    ],
    "metatags": [
     {
      "fb:app_id": "132970837947",
      "og:title": "How not to pay your bills",
      "og:type": "article",
      "og:image": "http://col.stb.s-msn.com/i/75/EB94FFD21D420CB9CF8F3CDAFC3F0.jpg",
      "og:site_name": "MSNMoney",
      "og:description": "Here's how to dodge the repo man and buy some time while you try to pull your financial life together."
     }
    ]
   }
  },
  {
   "kind": "customsearch#result",
   "title": "NFL Power Rankings - Top 32 NFL Football Teams - FOX Sports on ...",
   "htmlTitle": "NFL Power Rankings - Top 32 NFL Football Teams - FOX Sports on \u003cb\u003e...\u003c/b\u003e",
   "link": "http://msn.foxsports.com/nfl/powerRankings",
   "displayLink": "msn.foxsports.com",
   "snippet": "1 day ago ... Bills. 5-10, -, 14/29. C.J. Spiller rushed for 138 yards on 22 carries in the Dolphins   loss and is now averaging 6.5 yards per carry this season .",
   "htmlSnippet": "1 day ago \u003cb\u003e...\u003c/b\u003e \u003cb\u003eBills\u003c/b\u003e. 5-10, -, 14/29. C.J. Spiller rushed for 138 yards on 22 carries in the Dolphins \u003cbr\u003e  loss and is now averaging 6.5 yards per carry this season .",
   "formattedUrl": "msn.foxsports.com/nfl/powerRankings",
   "htmlFormattedUrl": "msn.foxsports.com/nfl/powerRankings",
   "pagemap": {
    "cse_image": [
     {
      "src": "http://msn.foxsports.com/component/photo/PR_BrianBillick"
     }
    ],
    "cse_thumbnail": [
     {
      "width": "144",
      "height": "109",
      "src": "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRWoJIC6-zUP5uKUSX6y_pUWQHMHY2i0uQKXn3WhV0X31s2c2iavfTldcY"
     }
    ],
    "metatags": [
     {
      "format-detection": "telephone=no",
      "og:title": "NFL Power Rankings - Top 32 NFL Football Teams - FOX Sports on MSN",
      "og:type": "article",
      "og:url": "http://msn.foxsports.com/nfl/powerRankings",
      "og:image": "http://static.foxsports.com/fe/images/newheader/logo.png",
      "og:description": "NFL Power Rankings on FOX Sports.  Weekly top 32 NFL team Power Rankings, National Football League team records and pro football insider comments.",
      "fb:app_id": "380390622023704",
      "og:site_name": "FOX Sports"
     }
    ]
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Buffalo Bills - FOX Sports on MSN l Sports News, Scores",
   "htmlTitle": "Buffalo \u003cb\u003eBills\u003c/b\u003e - FOX Sports on MSN l Sports News, Scores",
   "link": "http://msn.foxsports.com/nfl/team/buffalo-bills/67039",
   "displayLink": "msn.foxsports.com",
   "snippet": "19 hours ago ... Buffalo Bills team center, home page for Buffalo Bills news, videos, NFL team   reports, roster depth charts, results, stats, schedule and more.",
   "htmlSnippet": "19 hours ago \u003cb\u003e...\u003c/b\u003e Buffalo \u003cb\u003eBills\u003c/b\u003e team center, home page for Buffalo \u003cb\u003eBills\u003c/b\u003e news, videos, NFL team \u003cbr\u003e  reports, roster depth charts, results, stats, schedule and more.",
   "cacheId": "bubRqiIZrOkJ",
   "formattedUrl": "msn.foxsports.com/nfl/team/buffalo-bills/67039",
   "htmlFormattedUrl": "msn.foxsports.com/nfl/team/buffalo-\u003cb\u003ebills\u003c/b\u003e/67039",
   "pagemap": {
    "cse_image": [
     {
      "src": "http://msn.foxsports.com/fe/images/NFL/TeamLogo/Large/2.png"
     }
    ],
    "metatags": [
     {
      "format-detection": "telephone=no",
      "og:title": "Buffalo Bills",
      "og:type": "sports_team",
      "og:url": "http://msn.foxsports.com/nfl/team/buffalo-bills/67039",
      "og:image": "http://msn.foxsports.com/fe/images/NFL/TeamLogo/Large/2.png",
      "fb:app_id": "380390622023704",
      "og:site_name": "FOX Sports",
      "og:description": "Buffalo Bills team center, home page for Buffalo Bills news, videos, NFL team reports, roster depth charts, results, stats, schedule and more.",
      "medium": "news"
     }
    ]
   }
  },
  {
   "kind": "customsearch#result",
   "title": "Bush carries Dolphins past Bills - Fox Sports",
   "htmlTitle": "Bush carries Dolphins past \u003cb\u003eBills\u003c/b\u003e - Fox Sports",
   "link": "http://msn.foxsports.com/nfl/story/miami-dolphins-defeat-buffalo-bills-122312",
   "displayLink": "msn.foxsports.com",
   "snippet": "3 days ago ... Reggie Bush caught two touchdown passes and scored on a short run Sunday to   help the Miami Dolphins beat the Bills 24-10. Reggie Bush ...",
   "htmlSnippet": "3 days ago \u003cb\u003e...\u003c/b\u003e Reggie Bush caught two touchdown passes and scored on a short run Sunday to \u003cbr\u003e  help the Miami Dolphins beat the \u003cb\u003eBills\u003c/b\u003e 24-10. Reggie Bush \u003cb\u003e...\u003c/b\u003e",
   "formattedUrl": "msn.foxsports.com/nfl/story/miami-dolphins-defeat-buffalo-bills-122312",
   "htmlFormattedUrl": "msn.foxsports.com/nfl/story/miami-dolphins-defeat-buffalo-\u003cb\u003ebills\u003c/b\u003e-122312",
   "pagemap": {
    "cse_image": [
     {
      "src": "http://static.foxsports.com/content/fscom/img/2012/12/23/Miami-Dolphins-running-back-Reggie-Bush_20121223170408196_185_150.JPG"
     }
    ],
    "cse_thumbnail": [
     {
      "width": "148",
      "height": "120",
      "src": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRU2aeJS2iG8K1rJgBsPVXopfTAeZm6Aof4aAawEVD443vgEIuKI7-Rzw"
     }
    ],
    "metatags": [
     {
      "format-detection": "telephone=no",
      "og:title": "Bush carries Dolphins past Bills",
      "og:type": "article",
      "og:url": "http://msn.foxsports.com/nfl/story/miami-dolphins-defeat-buffalo-bills-122312",
      "og:image": "http://static.foxsports.com/content/fscom/img/2012/12/23/Miami-Dolphins-running-back-Reggie-Bush_20121223170408196_185_150.JPG",
      "og:description": "Reggie Bush caught two touchdown passes and scored on a short run Sunday to help the Miami Dolphins beat the Bills 24-10.",
      "fb:app_id": "380390622023704",
      "og:site_name": "FOX Sports",
      "medium": "news"
     }
    ]
   }
  }
 ]
}
