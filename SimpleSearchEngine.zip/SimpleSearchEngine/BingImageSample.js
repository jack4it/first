{
  "d": {
    "results": [
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=0&$top=1",
          "type": "ImageResult"
        },
        "ID": "0c700f6c-800d-4051-a7a7-a9f7b207a17d",
        "Title": "Xbox 720 Pictures | About the Xbox 720",
        "MediaUrl": "http://www.xbox720talk.com/wp-content/uploads/2011/08/Xbox-720.jpg",
        "SourceUrl": "http://www.xbox720talk.com/xbox720-pics/",
        "DisplayUrl": "www.xbox720talk.com/xbox720-pics",
        "Width": "1000",
        "Height": "857",
        "FileSize": "273697",
        "ContentType": "image/jpeg",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts3.mm.bing.net/th?id=H.4801611037541726&pid=15.1",
          "ContentType": "image/jpg",
          "Width": "300",
          "Height": "257",
          "FileSize": "8335"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=1&$top=1",
          "type": "ImageResult"
        },
        "ID": "90859a44-c76c-4cca-a48a-902fdbd9a74d",
        "Title": "Microsoft Xbox 360 Console Pics",
        "MediaUrl": "http://0.tqn.com/d/xbox/1/0/b/5/xbox360logo1.jpg",
        "SourceUrl": "http://xbox.about.com/od/xbox2/ss/xbox360pics_5.htm",
        "DisplayUrl": "xbox.about.com/od/xbox2/ss/xbox360pics_5.htm",
        "Width": "400",
        "Height": "260",
        "FileSize": "23935",
        "ContentType": "image/jpeg",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts3.mm.bing.net/th?id=H.4708955739586610&pid=15.1",
          "ContentType": "image/jpg",
          "Width": "300",
          "Height": "195",
          "FileSize": "5774"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=2&$top=1",
          "type": "ImageResult"
        },
        "ID": "4fd24b48-d2c4-40c0-b2e1-b7e6c9329211",
        "Title": "The retail Xbox package includes: 1 Xbox ...",
        "MediaUrl": "http://media.teamxbox.com/faq/xbox.jpg",
        "SourceUrl": "http://faq.teamxbox.com/detail/1/Xbox-Console-FirstGeneration/",
        "DisplayUrl": "faq.teamxbox.com/detail/1/Xbox-Console-FirstGeneration",
        "Width": "350",
        "Height": "353",
        "FileSize": "32483",
        "ContentType": "image/jpeg",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts3.mm.bing.net/th?id=H.4985504334414774&pid=15.1",
          "ContentType": "image/jpg",
          "Width": "297",
          "Height": "300",
          "FileSize": "9889"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=3&$top=1",
          "type": "ImageResult"
        },
        "ID": "946d62b9-bc25-40c8-8844-a3e8478e8b2f",
        "Title": "working both on the successor to the Xbox ...",
        "MediaUrl": "http://www.slipperybrick.com/wp-content/uploads/2009/05/xbox.jpg",
        "SourceUrl": "http://www.slipperybrick.com/category/xbox/page/9/",
        "DisplayUrl": "www.slipperybrick.com/category/xbox/page/9",
        "Width": "500",
        "Height": "520",
        "FileSize": "33805",
        "ContentType": "image/jpeg",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts1.mm.bing.net/th?id=H.4560203870045296&pid=15.1",
          "ContentType": "image/jpg",
          "Width": "288",
          "Height": "300",
          "FileSize": "9798"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=4&$top=1",
          "type": "ImageResult"
        },
        "ID": "860d12e1-ed1d-45b3-a94d-222e0c6a5163",
        "Title": " ... Xbox 360? Windows Unveils New Student Deal",
        "MediaUrl": "http://www.geardiary.com/wp-content/uploads/2011/05/360slim4gb1.jpg",
        "SourceUrl": "http://www.geardiary.com/2011/05/24/want-a-free-xbox-360-windows-unveils-new-student-deal/",
        "DisplayUrl": "www.geardiary.com/2011/05/24/want-a-free-xbox-360-windows...",
        "Width": "1000",
        "Height": "1000",
        "FileSize": "67011",
        "ContentType": "image/jpeg",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts4.mm.bing.net/th?id=H.4959541285421731&pid=15.1",
          "ContentType": "image/jpg",
          "Width": "300",
          "Height": "300",
          "FileSize": "6945"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=5&$top=1",
          "type": "ImageResult"
        },
        "ID": "a19a0736-8af3-408a-9e89-5cfbaa8952b0",
        "Title": "Xbox is 10 today | Online PR and social ...",
        "MediaUrl": "http://www.liberatemedia.com/wp-content/uploads/2011/11/xbox.jpg",
        "SourceUrl": "http://www.liberatemedia.com/blog/xbox-is-10-today/",
        "DisplayUrl": "www.liberatemedia.com/blog/xbox-is-10-today",
        "Width": "500",
        "Height": "500",
        "FileSize": "29692",
        "ContentType": "image/jpeg",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts1.mm.bing.net/th?id=H.4820349993027708&pid=15.1",
          "ContentType": "image/jpg",
          "Width": "300",
          "Height": "300",
          "FileSize": "10053"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=6&$top=1",
          "type": "ImageResult"
        },
        "ID": "bdf355e2-ed5f-4117-be02-3321d00f00a6",
        "Title": "Xbox 360 �C Wikip��dia, a enciclop��dia ...",
        "MediaUrl": "http://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Xbox_360_S.png/250px-Xbox_360_S.png",
        "SourceUrl": "http://pt.wikipedia.org/wiki/Xbox_360",
        "DisplayUrl": "pt.wikipedia.org/wiki/Xbox_360",
        "Width": "250",
        "Height": "275",
        "FileSize": "46326",
        "ContentType": "image/png",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts1.mm.bing.net/th?id=H.4629632002885096&pid=15.1",
          "ContentType": "image/jpg",
          "Width": "250",
          "Height": "275",
          "FileSize": "5608"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=7&$top=1",
          "type": "ImageResult"
        },
        "ID": "38e646b2-2749-451a-9712-86f8c7aa2cb4",
        "Title": " ... : Microsoft , Xbox 360 , Xbox 360 3D",
        "MediaUrl": "http://www.lainterfaz.com/wp-content/uploads/2011/05/xbox-360-3d.jpg",
        "SourceUrl": "http://www.lainterfaz.com/2011/05/23/xbox-360-3d/",
        "DisplayUrl": "www.lainterfaz.com/2011/05/23/xbox-360-3d",
        "Width": "791",
        "Height": "532",
        "FileSize": "57053",
        "ContentType": "image/jpeg",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts3.mm.bing.net/th?id=H.4845565744318398&pid=15.1",
          "ContentType": "image/jpg",
          "Width": "300",
          "Height": "201",
          "FileSize": "8168"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=8&$top=1",
          "type": "ImageResult"
        },
        "ID": "6334c3e6-6e27-4bbb-a06f-ee707292d5e6",
        "Title": "Xbox 360 : une version slim �� l��E3",
        "MediaUrl": "http://blog.1001actus.com/files/xbox3.jpg",
        "SourceUrl": "http://blog.1001actus.com/tag/xbox-360",
        "DisplayUrl": "blog.1001actus.com/tag/xbox-360",
        "Width": "468",
        "Height": "468",
        "FileSize": "30193",
        "ContentType": "image/jpeg",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts1.mm.bing.net/th?id=H.4956719512290036&pid=15.1",
          "ContentType": "image/jpg",
          "Width": "300",
          "Height": "300",
          "FileSize": "7388"
        }
      },
      {
        "__metadata": {
          "uri": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=9&$top=1",
          "type": "ImageResult"
        },
        "ID": "2c85b838-dac7-4133-898f-d7e0cb5f5de4",
        "Title": "Xbox 360 Laptop mk2",
        "MediaUrl": "http://www.blogcdn.com/www.engadget.com/media/2007/04/xbox-360-laptop-mk2-top.jpg",
        "SourceUrl": "http://www.engadget.com/2007/04/17/xbox-360-laptop-mk2/",
        "DisplayUrl": "www.engadget.com/2007/04/17/xbox-360-laptop-mk2",
        "Width": "440",
        "Height": "330",
        "FileSize": "62281",
        "ContentType": "image/jpeg",
        "Thumbnail": {
          "__metadata": {
            "type": "Bing.Thumbnail"
          },
          "MediaUrl": "http://ts2.mm.bing.net/th?id=H.4671576656709545&pid=15.1",
          "ContentType": "image/jpg",
          "Width": "300",
          "Height": "225",
          "FileSize": "11514"
        }
      }
    ],
    "__next": "https://api.datamarket.azure.com/Data.ashx/Bing/Search/Image?Options='DisableLocationDetection'&Query='xbox'&$skip=10&$top=10"
  }
}
